#!/bin/bash

# --blocks, checked against PLINK 1.9's .blocks and .blocks.det.
#
# The fixture plants 20 haplotype blocks of 12 variants each, so the scan has
# blocks to find and gaps to reject.

set -exo pipefail

awk -f make_vcf.awk > tmp_h.vcf
plink --vcf tmp_h.vcf --double-id --make-bed --out tmp_data > /dev/null

compare() {
    # .blocks is a whitespace-formatted variant list in PLINK 1.9 and
    # tab-delimited with a '#'-prefixed header in plink2; .blocks.det carries
    # the same information plus the span, so both are checked.
    diff -q <(grep -v '^#' "$1" | tr -s ' \t' ' ' | sed 's/^ //; s/ $//') \
            <(grep -v '^#' "$2" | tr -s ' \t' ' ' | sed 's/^ //; s/ $//')
    awk '
        function abs(x) { return (x < 0)? -x : x }
        FNR == NR {
            if (FNR > 1) { key = $1 "_" $2 "_" $3; kb[key] = $4; nsnps[key] = $5; snps[key] = $6; ++n1 }
            next
        }
        /^#/ { next }
        {
            ++n2;
            key = $1 "_" $2 "_" $3;
            if (!(key in kb)) { print "block missing from the PLINK 1.9 report: " key; failed = 1; exit 1 }
            if (nsnps[key] != $5 || snps[key] != $6) { print "block contents differ on " key; failed = 1; exit 1 }
            if (abs(kb[key] - $4) > 1e-3) { print "KB differs on " key ": " kb[key] " vs " $4; failed = 1; exit 1 }
        }
        END {
            if (failed) { exit 1 }
            if (n1 != n2) { print "block count mismatch: " n1 " vs " n2; exit 1 }
            if (n1 == 0) { print "no blocks found, so nothing was compared"; exit 1 }
            print n1 " blocks matched"
        }
    ' "$3" "$4"
}

# 1. Defaults ('no-pheno-req' because the fixture has no phenotype).
plink --bfile tmp_data --blocks no-pheno-req --out plink19
$1/plink2 $2 $3 --bfile tmp_data --blocks --blocks-max-kb 200 --out plink2
compare plink19.blocks plink2.blocks plink19.blocks.det plink2.blocks.det

# 2. Each parameter flag, one at a time.
#
# The --blocks-max-kb values include several smaller than the planted blocks'
# 22 kb span, so that the window truncates them and the greedy pass has to
# choose between overlapping candidates of equal length.
for opt in "--blocks-max-kb 4" "--blocks-max-kb 8" "--blocks-max-kb 10" \
           "--blocks-max-kb 12" "--blocks-max-kb 14" "--blocks-max-kb 16" \
           "--blocks-max-kb 30" "--blocks-max-kb 100" \
           "--blocks-max-kb 200 --blocks-min-maf 0.2" \
           "--blocks-max-kb 200 --blocks-min-maf 0.4" \
           "--blocks-max-kb 200 --blocks-strong-lowci 0.75" \
           "--blocks-max-kb 200 --blocks-strong-highci 0.9" \
           "--blocks-max-kb 200 --blocks-recomb-highci 0.8" \
           "--blocks-max-kb 200 --blocks-inform-frac 0.9" \
           "--blocks-max-kb 200 --blocks-inform-frac 0.99"
do
    plink --bfile tmp_data --blocks no-pheno-req $opt --out plink19_opt
    $1/plink2 $2 $3 --bfile tmp_data --blocks $opt --out plink2_opt
    compare plink19_opt.blocks plink2_opt.blocks plink19_opt.blocks.det plink2_opt.blocks.det
done

# 2b. A threshold strict enough to reject everything: both should find nothing.
plink --bfile tmp_data --blocks no-pheno-req --blocks-recomb-highci 0.7 --out plink19_none
$1/plink2 $2 $3 --bfile tmp_data --blocks --blocks-max-kb 200 --blocks-recomb-highci 0.7 --out plink2_none
test "$(grep -vc '^#' plink19_none.blocks)" -eq 0
test "$(grep -vc '^#' plink2_none.blocks)" -eq 0

# 3. 'no-small-max-span'.
plink --bfile tmp_data --blocks no-pheno-req no-small-max-span --out plink19_nsms
$1/plink2 $2 $3 --bfile tmp_data --blocks no-small-max-span --blocks-max-kb 200 --out plink2_nsms
compare plink19_nsms.blocks plink2_nsms.blocks plink19_nsms.blocks.det plink2_nsms.blocks.det

# 4. The result must not depend on --threads.
for t in 1 3 8
do
    $1/plink2 $2 $3 --bfile tmp_data --blocks --blocks-max-kb 200 --threads $t --out plink2_t$t
    diff -q plink2.blocks plink2_t$t.blocks
    diff -q plink2.blocks.det plink2_t$t.blocks.det
done

# 5. Multiallelic variants are kept, one allele against the rest, so splitting
#    a variant into a biallelic pair must not change the blocks it is in.
$1/plink2 $2 $3 --bfile tmp_data --make-pgen --out plink2_pgen
$1/plink2 $2 $3 --pfile plink2_pgen --blocks --blocks-max-kb 200 --out plink2_frompgen
diff -q plink2.blocks plink2_frompgen.blocks

# 7. Founder counts whose bit arrays take an odd number (7 or more) of words:
#    the three per-genotype masks were packed at that unaligned stride, and
#    PopcountWordsIntersect() crashed on them.  384 and 512 did not.
for n in 400 448 800
do
$1/plink2 $2 $3 --dummy $n 200 0.05 --seed 1 --blocks --blocks-max-kb 200 --out plink2_n$n
done
