#!/bin/bash

# Covers both --pmerge/--pmerge-list paths: the concatenation case, where the
# filesets' (chromosome, bp) ranges don't overlap, and the general case, where
# more than one fileset has something to say about the same variant.

set -exo pipefail

plink --simulate simulate.txt --simulate-missing 0.02 --out tmp_data

# Three chromosomes, so the parts have disjoint coordinate ranges.
head -n 99 tmp_data.bim > tmp_data1.bim
cat tmp_data.bim | sed -n '100,198p' | sed 's/^1/2/' > tmp_data2.bim
cat tmp_data.bim | tail -n 99 | sed 's/^1/3/' > tmp_data3.bim
cat tmp_data1.bim tmp_data2.bim tmp_data3.bim > tmp_data.bim

$1/plink2 $2 $3 --bfile tmp_data --make-pgen --out tmp_all

for c in 1 2 3
do
    $1/plink2 $2 $3 --pfile tmp_all --chr $c --make-pgen --out part$c
done

# 1. --pmerge, two filesets.
$1/plink2 $2 $3 --pfile part1 --pmerge part2 --out merged12
$1/plink2 $2 $3 --pfile tmp_all --chr 1,2 --make-pgen --out expected12
$1/plink2 $2 $3 --pfile merged12 --make-bed --out merged12b
$1/plink2 $2 $3 --pfile expected12 --make-bed --out expected12b
diff -q expected12b.bed merged12b.bed
diff -q expected12b.bim merged12b.bim
diff -q expected12b.fam merged12b.fam

# 2. --pmerge-list, all three, given as a list file.
echo part1 > tmp_list.txt
echo part2 >> tmp_list.txt
echo part3 >> tmp_list.txt
$1/plink2 $2 $3 --pmerge-list tmp_list.txt --out merged_all
$1/plink2 $2 $3 --pfile merged_all --make-bed --out merged_allb
$1/plink2 $2 $3 --pfile tmp_all --make-bed --out expected_allb
diff -q expected_allb.bed merged_allb.bed
diff -q expected_allb.bim merged_allb.bim
diff -q expected_allb.fam merged_allb.fam

# 3. Same, with the initially-loaded fileset supplying one of the parts.
echo part2 > tmp_list23.txt
echo part3 >> tmp_list23.txt
$1/plink2 $2 $3 --pfile part1 --pmerge-list tmp_list23.txt --out merged_all2
$1/plink2 $2 $3 --pfile merged_all2 --make-bed --out merged_all2b
diff -q expected_allb.bed merged_all2b.bed
diff -q expected_allb.bim merged_all2b.bim
diff -q expected_allb.fam merged_all2b.fam

# 4. Reversed input order: the result must not depend on it.
echo part3 > tmp_list_rev.txt
echo part2 >> tmp_list_rev.txt
echo part1 >> tmp_list_rev.txt
$1/plink2 $2 $3 --pmerge-list tmp_list_rev.txt --out merged_rev
$1/plink2 $2 $3 --pfile merged_rev --make-bed --out merged_revb
diff -q expected_allb.bed merged_revb.bed
diff -q expected_allb.bim merged_revb.bim

# 5. bfile mode, i.e. concatenating PLINK 1 filesets.
for c in 1 2 3
do
    $1/plink2 $2 $3 --pfile part$c --make-bed --out bpart$c
done
echo bpart1 > tmp_blist.txt
echo bpart2 >> tmp_blist.txt
echo bpart3 >> tmp_blist.txt
$1/plink2 $2 $3 --pmerge-list tmp_blist.txt bfile --out merged_b
$1/plink2 $2 $3 --pfile merged_b --make-bed --out merged_bb
diff -q expected_allb.bed merged_bb.bed
diff -q expected_allb.bim merged_bb.bim

# 6. Non-concatenating merges.  Every case below reassembles tmp_all from
#    overlapping slices of itself, so the result must reproduce tmp_all.
#    (PLINK 1.9 --bmerge agrees on these, but using tmp_all as the reference
#    makes the check exact and independent of 1.9's allele-order conventions.)
grep -v '^##' tmp_all.pvar > tmp_all_body.pvar

# 6a. Merging a fileset with itself is idempotent.
$1/plink2 $2 $3 --pfile part1 --pmerge part1 --out merged_self
$1/plink2 $2 $3 --pfile part1 --make-bed --out part1b
$1/plink2 $2 $3 --pfile merged_self --make-bed --out merged_selfb
diff -q part1b.bed merged_selfb.bed
diff -q part1b.bim merged_selfb.bim
diff -q part1b.fam merged_selfb.fam

sample_ct=`wc -l < tmp_data.fam`

# 6b. Split by sample into disjoint halves, every variant in both.
head -n $((sample_ct / 2)) tmp_data.fam | cut -f1,2 > tmp_sA.txt
tail -n $((sample_ct - sample_ct / 2)) tmp_data.fam | cut -f1,2 > tmp_sB.txt
$1/plink2 $2 $3 --pfile tmp_all --keep tmp_sA.txt --make-pgen --out sA
$1/plink2 $2 $3 --pfile tmp_all --keep tmp_sB.txt --make-pgen --out sB
$1/plink2 $2 $3 --pfile sA --pmerge sB --out merged_s
grep -v '^##' merged_s.pvar > merged_s_body.pvar
diff -q tmp_all_body.pvar merged_s_body.pvar
$1/plink2 $2 $3 --pfile merged_s --pgen-diff tmp_all --out diff_s
test `grep -cv '^#' diff_s.pdiff` -eq 0

# 6c. Split by sample with an overlapping block, so both filesets have
#     something to say about the same (variant, sample) cells.
head -n $((sample_ct * 3 / 5)) tmp_data.fam | cut -f1,2 > tmp_sC.txt
tail -n $((sample_ct * 3 / 5)) tmp_data.fam | cut -f1,2 > tmp_sD.txt
$1/plink2 $2 $3 --pfile tmp_all --keep tmp_sC.txt --make-pgen --out sC
$1/plink2 $2 $3 --pfile tmp_all --keep tmp_sD.txt --make-pgen --out sD
$1/plink2 $2 $3 --pfile sC --pmerge sD --out merged_so
grep -v '^##' merged_so.pvar > merged_so_body.pvar
diff -q tmp_all_body.pvar merged_so_body.pvar
$1/plink2 $2 $3 --pfile merged_so --pgen-diff tmp_all --out diff_so
test `grep -cv '^#' diff_so.pdiff` -eq 0

# 6d. Split by variant with an overlapping block, same samples throughout.
#     This is the classic PLINK 1.x --bmerge job.
grep -v '^#' tmp_all.pvar | cut -f3 > tmp_vids.txt
variant_ct=`wc -l < tmp_vids.txt`
head -n $((variant_ct * 2 / 3)) tmp_vids.txt > tmp_vA.txt
tail -n $((variant_ct * 2 / 3)) tmp_vids.txt > tmp_vB.txt
$1/plink2 $2 $3 --pfile tmp_all --extract tmp_vA.txt --make-pgen --out vA
$1/plink2 $2 $3 --pfile tmp_all --extract tmp_vB.txt --make-pgen --out vB
$1/plink2 $2 $3 --pfile vA --pmerge vB --out merged_v
grep -v '^##' merged_v.pvar > merged_v_body.pvar
diff -q tmp_all_body.pvar merged_v_body.pvar
$1/plink2 $2 $3 --pfile merged_v --pgen-diff tmp_all --out diff_v
test `grep -cv '^#' diff_v.pdiff` -eq 0

# 6e. Three-way non-concatenating merge, split both ways at once.
$1/plink2 $2 $3 --pfile tmp_all --keep tmp_sA.txt --extract tmp_vA.txt --make-pgen --out xA
$1/plink2 $2 $3 --pfile tmp_all --keep tmp_sB.txt --extract tmp_vB.txt --make-pgen --out xB
echo xA > tmp_xlist.txt
echo xB >> tmp_xlist.txt
echo tmp_all >> tmp_xlist.txt
$1/plink2 $2 $3 --pmerge-list tmp_xlist.txt --out merged_x
grep -v '^##' merged_x.pvar > merged_x_body.pvar
diff -q tmp_all_body.pvar merged_x_body.pvar
$1/plink2 $2 $3 --pfile merged_x --pgen-diff tmp_all --out diff_x
test `grep -cv '^#' diff_x.pdiff` -eq 0

# 6f. Dosages and phase, split by sample with an overlapping block.  Compared
#     through exported VCFs, since --pgen-diff ignores phase.
$1/plink2 $2 $3 --vcf dosage_phase.vcf dosage=DS --make-pgen --out dp_all
$1/plink2 $2 $3 --pfile dp_all --export vcf vcf-dosage=DS --out dp_allv
grep -v '^##' dp_allv.vcf > dp_all_body.vcf
printf 's1\ns2\ns3\ns4\n' > tmp_dpA.txt
printf 's3\ns4\ns5\ns6\n' > tmp_dpB.txt
$1/plink2 $2 $3 --pfile dp_all --keep tmp_dpA.txt --make-pgen --out dpA
$1/plink2 $2 $3 --pfile dp_all --keep tmp_dpB.txt --make-pgen --out dpB
$1/plink2 $2 $3 --pfile dpA --pmerge dpB --out merged_dp
$1/plink2 $2 $3 --pfile merged_dp --export vcf vcf-dosage=DS --out merged_dpv
grep -v '^##' merged_dpv.vcf > merged_dp_body.vcf
diff -q dp_all_body.vcf merged_dp_body.vcf

# 6g. Same data, split by variant instead, so a merged variant's records sit
#     at different variant indices in their respective .pgens.
printf 'v1\nv2\nv3\n' > tmp_dpvA.txt
printf 'v2\nv3\nv4\n' > tmp_dpvB.txt
$1/plink2 $2 $3 --pfile dp_all --extract tmp_dpvA.txt --make-pgen --out dpvA
$1/plink2 $2 $3 --pfile dp_all --extract tmp_dpvB.txt --make-pgen --out dpvB
$1/plink2 $2 $3 --pfile dpvA --pmerge dpvB --out merged_dpv2
$1/plink2 $2 $3 --pfile merged_dpv2 --export vcf vcf-dosage=DS --out merged_dpv2x
grep -v '^##' merged_dpv2x.vcf > merged_dpv2_body.vcf
diff -q dp_all_body.vcf merged_dpv2_body.vcf

# 6h. Staggered variant indices where only one fileset has dosages, and the
#     shared variant sits at a different index in each.  Regression guard: the
#     phase/dosage presence scan used to read the first record's variant index
#     out of every other record's .pgen, which crashes here.
$1/plink2 $2 $3 --vcf mixed_a.vcf dosage=DS --make-pgen --out mixed_a
$1/plink2 $2 $3 --vcf mixed_b.vcf dosage=DS --make-pgen --out mixed_b
$1/plink2 $2 $3 --pfile mixed_a --pmerge mixed_b --out merged_mixed
$1/plink2 $2 $3 --pfile merged_mixed --export vcf vcf-dosage=DS --out merged_mixedv
grep -v '^##' merged_mixedv.vcf > merged_mixed_body.vcf
diff -q expected_mixed.vcfbody merged_mixed_body.vcf

# 7. --merge-mode nm-match over a group of records.  Same-position same-ID
#    duplicates inside one fileset are the only way to reach the genotype merge
#    while the job stays a concatenation, so the fixtures pair them with a
#    fileset on chromosome 2.  The _a and _b fixtures hold the same data with
#    the two records of each variant swapped, and both are checked against the
#    same expected output, since "nonmissing values must match" is symmetric:
#      s1 is missing in every record, so it must stay missing;
#      s2 is missing in one record and called in the other, so the call wins;
#      s3 has two different calls, which is the one genuine conflict.
#    nmdos covers the same three cases on the dosage track.
for o in a b
do
    $1/plink2 $2 $3 --vcf nmdup_$o.vcf --make-pgen --out tmp_nmdup_$o
    $1/plink2 $2 $3 --vcf nmdos_$o.vcf dosage=DS --make-pgen --out tmp_nmdos_$o
done
$1/plink2 $2 $3 --vcf nmdup_other.vcf --make-pgen --out tmp_nmother

for o in a b
do
    $1/plink2 $2 $3 --pfile tmp_nmdup_$o --pmerge tmp_nmother --merge-mode nm-match --out tmp_nmdupm_$o
    $1/plink2 $2 $3 --pfile tmp_nmdupm_$o --export vcf --out tmp_nmdupx_$o
    grep -v '^#' tmp_nmdupx_$o.vcf > tmp_nmdup_body_$o.vcf
    diff -q nmdup_expected.vcfbody tmp_nmdup_body_$o.vcf

    $1/plink2 $2 $3 --pfile tmp_nmdos_$o --pmerge tmp_nmother --merge-mode nm-match --out tmp_nmdosm_$o
    $1/plink2 $2 $3 --pfile tmp_nmdosm_$o --export vcf vcf-dosage=DS --out tmp_nmdosx_$o
    grep -v '^#' tmp_nmdosx_$o.vcf > tmp_nmdos_body_$o.vcf
    diff -q nmdos_expected.vcfbody tmp_nmdos_body_$o.vcf
done

# 8. Merge conflicts.  'first' never consults a later record, so it is exact
#    regardless of how conflicts are resolved; nm-match and nm-first are
#    checked against the rules themselves by check_merge.py, which applies
#    them to whatever the fixtures import to rather than to a transcript of
#    today's output.

# 8a. Hardcall, dosage and phase conflicts, same samples and variants in both
#     filesets.  'keep first value, even if missing' means the merge of (a, b)
#     must reproduce a exactly, and (b, a) must reproduce b.
$1/plink2 $2 $3 --vcf conflict_a.vcf dosage=DS --make-pgen --out ca
$1/plink2 $2 $3 --vcf conflict_b.vcf dosage=DS --make-pgen --out cb
$1/plink2 $2 $3 --pfile ca --export vcf vcf-dosage=DS --out cax
$1/plink2 $2 $3 --pfile cb --export vcf vcf-dosage=DS --out cbx
grep -v '^##' cax.vcf > ca_body.vcf
grep -v '^##' cbx.vcf > cb_body.vcf
$1/plink2 $2 $3 --pfile ca --pmerge cb --merge-mode first --out cf_ab
$1/plink2 $2 $3 --pfile cf_ab --export vcf vcf-dosage=DS --out cf_abx
grep -v '^##' cf_abx.vcf > cf_ab_body.vcf
diff -q ca_body.vcf cf_ab_body.vcf
$1/plink2 $2 $3 --pfile cb --pmerge ca --merge-mode first --out cf_ba
$1/plink2 $2 $3 --pfile cf_ba --export vcf vcf-dosage=DS --out cf_bax
grep -v '^##' cf_bax.vcf > cf_ba_body.vcf
diff -q cb_body.vcf cf_ba_body.vcf

# 8b. Same, with multiallelic hardcalls.  ALTx/ALTy genotypes have their own
#     representation, so they get their own pass through the conflict path.
$1/plink2 $2 $3 --vcf conflictm_a.vcf --make-pgen --out cma
$1/plink2 $2 $3 --vcf conflictm_b.vcf --make-pgen --out cmb
$1/plink2 $2 $3 --pfile cma --export vcf --out cmax
grep -v '^##' cmax.vcf > cma_body.vcf
$1/plink2 $2 $3 --pfile cma --pmerge cmb --merge-mode first --out cmf
$1/plink2 $2 $3 --pfile cmf --export vcf --out cmfx
grep -v '^##' cmfx.vcf > cmf_body.vcf
diff -q cma_body.vcf cmf_body.vcf

# 8c. QUAL/FILTER/INFO conflicts.  'first' keeps the first value even when it
#     is missing; 'nm-first' takes the first nonmissing one, which differs on
#     u3, where fileset a has no QUAL or FILTER but does have an INFO value.
$1/plink2 $2 $3 --vcf qfi_a.vcf --make-pgen --out qa
$1/plink2 $2 $3 --vcf qfi_b.vcf --make-pgen --out qb
$1/plink2 $2 $3 --pfile qa --pmerge qb --merge-qual-mode first --merge-filter-mode first --merge-info-mode first --out qm_first
grep -v '^##' qm_first.pvar > qm_first_body.pvar
diff -q expected_qfi_first.pvarbody qm_first_body.pvar
$1/plink2 $2 $3 --pfile qa --pmerge qb --merge-qual-mode nm-first --merge-filter-mode nm-first --merge-info-mode nm-first --out qm_nmfirst
grep -v '^##' qm_nmfirst.pvar > qm_nmfirst_body.pvar
diff -q expected_qfi_nmfirst.pvarbody qm_nmfirst_body.pvar

# 8d. The same conflicts under nm-match and nm-first, checked against the
#     documented rules: a sample identical in both inputs survives unchanged
#     whatever its neighbours do, a one-sided value wins, and the two modes
#     differ only where both inputs have a value.
$1/plink2 $2 $3 --pfile ca --pmerge cb --merge-mode nm-match --out c_nmmatch
$1/plink2 $2 $3 --pfile c_nmmatch --export vcf vcf-dosage=DS --out c_nmmatchx
grep -v '^##' c_nmmatchx.vcf > c_nmmatch_body.vcf
python3 check_merge.py ca_body.vcf cb_body.vcf c_nmmatch_body.vcf nm-match
$1/plink2 $2 $3 --pfile ca --pmerge cb --merge-mode nm-first --out c_nmfirst
$1/plink2 $2 $3 --pfile c_nmfirst --export vcf vcf-dosage=DS --out c_nmfirstx
grep -v '^##' c_nmfirstx.vcf > c_nmfirst_body.vcf
python3 check_merge.py ca_body.vcf cb_body.vcf c_nmfirst_body.vcf nm-first

# 8e. Same for the multiallelic fixtures, where an ALTx/ALTy genotype has its
#     own representation and a clobbered sample used to take its neighbours
#     with it.
$1/plink2 $2 $3 --pfile cmb --export vcf --out cmbx
grep -v '^##' cmbx.vcf > cmb_body.vcf
$1/plink2 $2 $3 --pfile cma --pmerge cmb --merge-mode nm-match --out cm_nmmatch
$1/plink2 $2 $3 --pfile cm_nmmatch --export vcf --out cm_nmmatchx
grep -v '^##' cm_nmmatchx.vcf > cm_nmmatch_body.vcf
python3 check_merge.py cma_body.vcf cmb_body.vcf cm_nmmatch_body.vcf nm-match
$1/plink2 $2 $3 --pfile cma --pmerge cmb --merge-mode nm-first --out cm_nmfirst
$1/plink2 $2 $3 --pfile cm_nmfirst --export vcf --out cm_nmfirstx
grep -v '^##' cm_nmfirstx.vcf > cm_nmfirst_body.vcf
python3 check_merge.py cma_body.vcf cmb_body.vcf cm_nmfirst_body.vcf nm-first

# 8f. nm-match is symmetric by definition, so swapping the two filesets has to
#     give the same result.  This covers the whole call, dosage included:
#     a dosage present in only one input used to survive only when that input
#     came first (#473).
$1/plink2 $2 $3 --pfile cb --pmerge ca --merge-mode nm-match --out c_nmmatch_rev
$1/plink2 $2 $3 --pfile c_nmmatch_rev --export vcf vcf-dosage=DS --out c_nmmatch_revx
diff <(grep -v '^##' c_nmmatchx.vcf) <(grep -v '^##' c_nmmatch_revx.vcf)

#     Same for the multiallelic fixtures, where a genotype was dropped when
#     the missing record came second (#472).
$1/plink2 $2 $3 --pfile cmb --pmerge cma --merge-mode nm-match --out cm_nmmatch_rev
$1/plink2 $2 $3 --pfile cm_nmmatch_rev --export vcf --out cm_nmmatch_revx
diff <(grep -v '^##' cm_nmmatchx.vcf) <(grep -v '^##' cm_nmmatch_revx.vcf)

#     nm-match over a group of records is symmetric the same way, so the
#     sample-split fixtures from 6f swap too.  The two filesets overlap on
#     s3 and s4 only, so this is the case where the merge has to reconcile
#     records rather than concatenate them.  --indiv-sort defaults to
#     'natural' when merging, so both directions write the same sample order
#     and the bodies compare directly.
$1/plink2 $2 $3 --pfile dpA --pmerge dpB --merge-mode nm-match --out dp_nmmatch
$1/plink2 $2 $3 --pfile dpB --pmerge dpA --merge-mode nm-match --out dp_nmmatch_rev
$1/plink2 $2 $3 --pfile dp_nmmatch --export vcf vcf-dosage=DS --out dp_nmmatchx
$1/plink2 $2 $3 --pfile dp_nmmatch_rev --export vcf vcf-dosage=DS --out dp_nmmatch_revx
head -1 <(grep -v '^##' dp_nmmatchx.vcf) | cut -f10- | grep -qx 's1	s2	s3	s4	s5	s6'
diff <(grep -v '^##' dp_nmmatchx.vcf) <(grep -v '^##' dp_nmmatch_revx.vcf)

# 8g. An INFO conflict under nm-match resolves to a missing value, and the
#     .pvar stays the size of its contents.  Per key: NS differs on u1 and
#     goes missing while AA agrees and survives, and AA differs on u3.  QUAL
#     10 against 99 goes missing; FILTER PASS against q10 keeps q10, since
#     PASS records the absence of a failing filter rather than a value of its
#     own.
$1/plink2 $2 $3 --pfile qa --pmerge qb --merge-qual-mode nm-match --merge-filter-mode nm-match --merge-info-mode nm-match --out qm_nmmatch
test "$(tr -d '\0' < qm_nmmatch.pvar | wc -c)" -eq "$(wc -c < qm_nmmatch.pvar)"
grep -v '^##' qm_nmmatch.pvar > qm_nmmatch_body.pvar
diff -q expected_qfi_nmmatch.pvarbody qm_nmmatch_body.pvar

echo "TEST_PMERGE passed."
